import{ssrElement as P,mergeProps as R,ssr as n,ssrHydrationKey as o,escape as e,createComponent as t,Portal as B,ssrAttribute as l}from"solid-js/web";import{c as d,g as _,I as b,B as m}from"./App-D2_UlRqd.js";import{makePersisted as I}from"@solid-primitives/storage";import{createTimer as A}from"@solid-primitives/timer";import{getCurrentWindow as S}from"@tauri-apps/api/window";import{ask as F}from"@tauri-apps/plugin-dialog";import{relaunch as W}from"@tauri-apps/plugin-process";import{createSignal as h,createResource as M,createEffect as Y,startTransition as j,Show as k,For as D,onCleanup as N,onMount as L,Switch as H,Match as $}from"solid-js";import{createStore as J}from"solid-js/store";import{M as K}from"./ModeSelect-k59eGGTH.js";import{type as v}from"@tauri-apps/plugin-os";import{cx as C}from"cva";import{C as Q}from"./CaptionControlsWindows11-Bbsa7tUU.js";import{I as Z}from"./volume2-vfV-eD5G.js";import"@tanstack/solid-query";import"@tauri-apps/api/webviewWindow";import"@solid-primitives/event-listener";import"@solid-primitives/resize-observer";import"@tauri-apps/plugin-clipboard-manager";import"@tauri-apps/plugin-store";import"@tauri-apps/api/core";import"@tauri-apps/api/event";import"./OptionsContext-DEoc9GIR.js";import"@solid-primitives/context";import"zod";import"@ts-rest/core";import"@tauri-apps/plugin-http";import"./check-BB8ycQUG.js";import"./instant-Bwd_V5wX.js";import"./screenshot-BB0rO6jo.js";var U='<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298zM22 9l-6 6m0-6l6 6"></path>';const V=(i={})=>P("svg",R({viewBox:"0 0 24 24",width:"1.2em",height:"1.2em"},i),()=>n(U),!0),X="/_server/assets/cloud-1-0EtYTpJQ.png",ee="/_server/assets/cloud-2-C48ZYBEu.png",te="/_server/assets/cloud-3-SWvz_Fyk.png",re="/_server/assets/tears-and-fireflies-adi-goldstein-CggkdS0h.mp3";var ie=["<div",' class="flex flex-col items-center"><!--$-->','<!--/--><h1 class="text-[1.2rem] font-[700] mb-1 text-[--text-primary]">Permissions Required</h1><p class="text-gray-11">Orbit needs permissions to run properly.</p></div>'],ae=["<ul",' class="flex flex-col gap-4 py-8">',"</ul>"],se=["<div",' class="flex flex-col items-center"><!--$-->','<!--/--><h1 class="text-[1.2rem] font-[700] mb-1 text-[--text-primary]">Select Recording Mode</h1><p class="text-gray-11">Choose how you want to record with Orbit. You can change this later.</p></div>'],ne=["<div",' class="w-full py-4">',"</div>"],oe=["<div",' class="flex flex-col px-[2rem] text-[0.875rem] font-[400] flex-1 bg-gray-1 justify-evenly items-center"><!--$-->',"<!--/--><!--$-->","<!--/--><!--$-->","<!--/--></div>"],le=["<li",' class="flex flex-row items-center gap-4"><div class="flex flex-col flex-[2]"><span class="font-[500] text-[0.875rem] text-[--text-primary]"><!--$-->','<!--/--> Permission</span><span class="text-[--text-secondary]">',"</span></div><!--$-->","<!--/--></li>"],ce=["<div",' class="absolute inset-0 z-40"><header class="absolute top-0 inset-x-0 h-12 z-10" data-tauri-drag-region><div'," data-tauri-drag-region><button",">","</button><!--$-->",`<!--/--></div></header><style>
          body {
            background: transparent !important;
          }

          .content-container {
            transition: all 600ms cubic-bezier(0.4, 0, 0.2, 1);
          }

          .content-container.exiting {
            opacity: 0;
            transform: scale(1.1);
          }

          .custom-bg {
            transition: all 600ms cubic-bezier(0.4, 0, 0.2, 1);
          }

          .cloud-1.exiting {
            transform: translate(-200px, -150px) !important;
            opacity: 0 !important;
          }

          .cloud-2.exiting {
            transform: translate(200px, -150px) !important;
            opacity: 0 !important;
          }

          .cloud-3.exiting {
            transform: translate(-50%, 200px) !important;
            opacity: 0 !important;
          }

          .cloud-transition {
            transition: transform 600ms cubic-bezier(0.4, 0, 0.2, 1),
                        opacity 600ms cubic-bezier(0.4, 0, 0.2, 1) !important;
          }

          .cloud-image {
            max-width: 100vw;
            height: auto;
          }

          .grain {
            position: fixed;
            top: -150%;
            left: -50%;
            right: -50%;
            bottom: -150%;
            width: 200%;
            height: 400%;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='1.5' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
            pointer-events: none;
            opacity: 0.5;
            z-index: 200;
            mix-blend-mode: overlay;
          }

          /* Overlay for fade to black */
          .fade-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: transparent;
            opacity: 0;
            pointer-events: none;
            transition: opacity 600ms cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
          }

          .fade-overlay.exiting {
            opacity: 1;
          }

          @keyframes bounce {
            0%, 100% {
              transform: translateY(0);
            }
            50% {
              transform: translateY(-20px);
            }
          }

          .logo-bounce {
            animation: bounce 1s cubic-bezier(0.36, 0, 0.66, -0.56) forwards;
          }
        </style><div class="`,'"></div><div style="','"','><div class="grain"></div><div id="cloud-1" class="','"><img class="cloud-image w-[100vw] md:w-[80vw] -mr-40"',' alt="Cloud One"></div><div id="cloud-2" class="','"><img class="cloud-image w-[100vw] md:w-[80vw] -ml-40"',' alt="Cloud Two"></div><div id="cloud-3" class="','"><img class="cloud-image w-[180vw] md:w-[180vw]"',' alt="Cloud Three"></div><div class="','"><div class="text-center mb-8"><div class="cursor-pointer inline-block">','</div><h1 class="text-5xl md:text-5xl font-bold mb-4 drop-shadow-[0_0_20px_rgba(0,0,0,0.2)]">Welcome to Orbit</h1><p class="text-2xl opacity-80 max-w-md mx-auto drop-shadow-[0_0_20px_rgba(0,0,0,0.2)]">Beautiful screen recordings, owned by you.</p></div><!--$-->',"<!--/--></div></div></div>"];function E(i){return i==="granted"||i==="notNeeded"}const q=[{name:"Screen Recording",key:"screenRecording",description:"Add Orbit in System Settings, then restart the app for changes to take effect.",requiresManualGrant:!0},{name:"Accessibility",key:"accessibility",description:"During recording, Orbit collects mouse activity locally to generate automatic zoom in segments.",requiresManualGrant:!1},{name:"Microphone",key:"microphone",description:"This permission is required to record audio in your recordings.",requiresManualGrant:!1},{name:"Camera",key:"camera",description:"This permission is required to record your camera in your recordings.",requiresManualGrant:!1}];function de(){const[i,c]=h(!0),[y,a]=M(()=>d.doPermissionsCheck(i())),[u,p]=h("permissions");Y(()=>{i()||A(()=>j(()=>a.refetch()),250,setInterval)});const g=async r=>{try{await d.requestPermission(r)}catch(s){console.error(`Error occurred while requesting permission: ${s}`)}c(!1)},f=async r=>{await d.openPermissionSettings(r),r==="screenRecording"&&await F("After adding Orbit in System Settings, you'll need to restart the app for the permission to take effect.",{title:"Restart Required",kind:"info",okLabel:"Restart, I've granted permission",cancelLabel:"No, I still need to add it"})&&await W(),c(!1)},[x,w]=M(()=>_.get().then(r=>r===void 0?!0:!r.hasCompletedStartup)),z=()=>{d.showWindow({Main:{init_target_mode:null}}).then(()=>{S().close()})};return n(oe,o(),x()&&e(t(me,{onClose:()=>{w.mutate(!1)}})),e(t(k,{get when(){return u()==="permissions"},get children(){return[n(ie,o(),e(t(b,{class:"size-14 mb-3"}))),n(ae,o(),e(t(D,{each:q,children:r=>{const s=()=>y()?.[r.key];return t(k,{get when(){return s()!=="notNeeded"},get children(){return n(le,o(),e(r.name),e(r.description),e(t(m,{class:"flex-1 shrink-0",onClick:()=>r.requiresManualGrant||s()==="denied"?f(r.key):g(r.key),get disabled(){return E(s())},get children(){return s()==="granted"?"Granted":r.requiresManualGrant||s()==="denied"?"Open Settings":"Grant Permission"}})))}})}}))),t(m,{class:"px-12",size:"lg",get disabled(){return q.find(r=>!E(y()?.[r.key]))!==void 0},onClick:()=>p("mode"),children:"Continue"})]}})),e(t(k,{get when(){return u()==="mode"},get children(){return[n(se,o(),e(t(b,{class:"size-14 mb-3"}))),n(ne,o(),e(t(K,{}))),t(m,{class:"px-12",size:"lg",onClick:z,children:"Continue to Orbit"})]}})))}function me(i){const[c,y]=I(J({isMuted:!1}),{name:"audioSettings"}),[a,u]=h(!1),p=new Audio(re);c.isMuted||p.play();let g,f,x;const[w,z]=h(!1),r=()=>_.set({hasCompletedStartup:!0}),s=async()=>{u(!0),g?.cancel(),f?.cancel(),x?.cancel(),await r(),setTimeout(async()=>{i.onClose()},600)};return N(()=>p.pause()),L(()=>{const O=document.getElementById("cloud-1"),T=document.getElementById("cloud-2"),G=document.getElementById("cloud-3");g=O?.animate([{transform:"translate(0, 0)"},{transform:"translate(-20px, 10px)"},{transform:"translate(0, 0)"}],{duration:3e4,iterations:1/0,easing:"linear"}),f=T?.animate([{transform:"translate(0, 0)"},{transform:"translate(20px, 10px)"},{transform:"translate(0, 0)"}],{duration:35e3,iterations:1/0,easing:"linear"}),x=G?.animate([{transform:"translate(-50%, 20px)"},{transform:"translate(-48%, 0)"},{transform:"translate(-50%, 0)"}],{duration:6e4,iterations:1,easing:"cubic-bezier(0.4, 0, 0.2, 1)",fill:"forwards"})}),t(B,{get children(){return n(ce,o(),l("class",e(C("flex justify-between items-center gap-[0.25rem] w-full h-full z-10",v()==="windows"?"flex-row":"flex-row-reverse"),!0),!1),l("class",e(C("mx-4 text-solid-white hover:text-[#DDD] transition-colors",a()&&"opacity-0"),!0),!1),c.isMuted?e(t(V,{class:"w-6 h-6"})):e(t(Z,{class:"w-6 h-6"})),v()==="windows"&&e(t(Q,{})),`fade-overlay ${a()?"exiting":""}`,"transition-duration:600ms",l("class",e(C("flex flex-col h-screen custom-bg relative overflow-hidden transition-opacity text-solid-white",a()&&"exiting opacity-0"),!0),!1),`absolute top-0 right-0 opacity-70 pointer-events-none cloud-transition cloud-1 ${a()?"exiting":""}`,l("src",e(X,!0),!1),`absolute top-0 left-0 opacity-70 pointer-events-none cloud-transition cloud-2 ${a()?"exiting":""}`,l("src",e(ee,!0),!1),`absolute -bottom-[15%] left-1/2 -translate-x-1/2 opacity-70 pointer-events-none cloud-transition cloud-3 ${a()?"exiting":""}`,l("src",e(te,!0),!1),`content-container flex flex-col items-center justify-center flex-1 relative px-4 ${a()?"exiting":""}`,e(t(b,{get class(){return`w-20 h-24 mx-auto drop-shadow-[0_0_100px_rgba(0,0,0,0.2)]
                  ${w()?"logo-bounce":""}`}})),e(t(H,{get children(){return[t($,{get when(){return v()!=="windows"},get children(){return t(m,{class:"px-12 text-lg shadow-[0_0_30px_rgba(0,0,0,0.1)]",variant:"gray",size:"lg",onClick:s,children:"Get Started"})}}),t($,{get when(){return v()==="windows"},get children(){return t(m,{class:"px-12",size:"lg",onClick:async()=>{r(),await d.showWindow({Main:{init_target_mode:null}}),S().close()},children:"Continue to Orbit"})}})]}})))}})}export{de as default};
